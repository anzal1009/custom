{''
 'name': 'Eastea API',
 'summary': """API for ERP""",
 'version': '0.1',
'sequence':'-60',
 'description': """API for ERP""",
 'author': 'Ideenkreise Tech Pvt Ltd',
 'company': 'Ideenkreise Tech Pvt Ltd',
 'website': 'https://www.ideenkreisetech.com',
 'category': 'Tools',
#  'depends': ['stock'],
 'license': 'AGPL-3',
 'data': ['security/ir.model.access.csv',
#  'views/test_team.xml',
#  'views/product_qc.xml',
#  'views/quality_check.xml',

          ],
 'demo': [],
 'installable': True,
 'auto_install': False,
 'application' : True
 }
